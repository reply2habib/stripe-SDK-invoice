<?php 


require_once('vendor/autoload.php'); // Path to your autoload.php

try {
    // Set your test API key
    \Stripe\Stripe::setApiKey('sk_test_XXXXXXXXXXXXXXXXXXXXXXXX');

    // Create a customer
    $customer = \Stripe\Customer::create([
        'email' => 'customer@example.com', // Customer's email
        'name' => 'Customer Name', // Customer's name (optional)
        // You can add more details here like address, phone, etc.
    ]);

    // Create a Payment Intent for the customer (chargeable payment)
    $paymentIntent = \Stripe\PaymentIntent::create([
        'amount' => 14000, // Amount in cents ($140.00)
        'currency' => 'usd',
        'customer' => $customer->id,
        'description' => 'Payment for services', // Description of the charge
    ]);

    // Create an invoice for the customer
    $invoice = \Stripe\Invoice::create([
        'customer' => $customer->id,
        'collection_method' => 'send_invoice', // Set the collection method to 'send_invoice'
        'due_date' => strtotime('+7 days'), // Set the due date 7 days from now
        'description' => 'Invoice for Payment Intent: ' . $paymentIntent->id, // Include a reference to the Payment Intent in the invoice description
    ]);

    // Send the invoice to the customer
    $invoice->sendInvoice();

    // Update the Payment Intent's description with a reference to the Invoice
    $paymentIntent->description = 'Payment Intent associated with Invoice: ' . $invoice->id;
    $paymentIntent->save();

    echo 'Payment intent created with ID: ' . $paymentIntent->id . '<br>';
    echo 'Invoice created and sent to customer with ID: ' . $invoice->id;
} catch (\Stripe\Exception\ApiErrorException $e) {
    // Handle Stripe API errors
    echo 'Error: ' . $e->getMessage();
} catch (Exception $e) {
    // Handle other exceptions
    echo 'Error: ' . $e->getMessage();
}

